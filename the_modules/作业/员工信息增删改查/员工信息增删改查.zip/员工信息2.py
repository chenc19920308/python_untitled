COLUMNS = ["id", "name", "age", "phone", "occupation", "hire_data"]
staff_table = "employee_info.txt"

def load_tab(file):
    data = {}
    with open(file, 'r', encoding='utf-8') as f:
        for i in COLUMNS:
            data[i] = []
            data_mark = COLUMNS.index(i)
            for line in f:
                data[i].append(line[data_mark])
    print(data)
load_tab(staff_table)




